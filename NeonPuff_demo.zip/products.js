// Product data for the demo store (no backend).
// Base prices are stored in UAH.
window.STORE_PRODUCTS = [
  {
    id: "np-ice-mint-6000",
    category: "vapes",
    accent: "mint",
    emoji: "🧊",
    price_uah: 1890,
    puffs: 6000,
    nicotine: "2% (20mg/ml)",
    i18n: {
      ru: {
        name: "Одноразовый вейп Ice Mint",
        flavor: "Лёд • Мята",
        badge: "Хит",
        desc: "Холодная мята. Ровная тяга. Компактный формат для тех, кто любит свежесть.",
      },
      uk: {
        name: "Одноразовий вейп Ice Mint",
        flavor: "Лід • М'ята",
        badge: "Хіт",
        desc: "Холодна м'ята. Рівна тяга. Компактний формат для тих, хто любить свіжість.",
      },
      en: {
        name: "Disposable Vape Ice Mint",
        flavor: "Ice • Mint",
        badge: "Bestseller",
        desc: "Cold mint profile with a clean hit. Compact format for people who like freshness.",
      },
    },
  },
  {
    id: "np-tropical-5000",
    category: "vapes",
    accent: "tropical",
    emoji: "🥭",
    price_uah: 1790,
    puffs: 5000,
    nicotine: "2% (20mg/ml)",
    i18n: {
      ru: {
        name: "Одноразовый вейп Tropical Mix",
        flavor: "Манго • Ананас",
        badge: "Новый вкус",
        desc: "Тропический микс без лишней сладости. Яркий вкус без приторности.",
      },
      uk: {
        name: "Одноразовий вейп Tropical Mix",
        flavor: "Манго • Ананас",
        badge: "Новий смак",
        desc: "Тропічний мікс без зайвої солодкості. Яскравий смак без нудотності.",
      },
      en: {
        name: "Disposable Vape Tropical Mix",
        flavor: "Mango • Pineapple",
        badge: "New flavor",
        desc: "Tropical mix without extra sweetness. Bright taste without being too sugary.",
      },
    },
  },
  {
    id: "np-berry-4500",
    category: "vapes",
    accent: "berry",
    emoji: "🫐",
    price_uah: 1690,
    puffs: 4500,
    nicotine: "2% (20mg/ml)",
    i18n: {
      ru: {
        name: "Одноразовый вейп Berry Rush",
        flavor: "Ягоды • Лёгкий холодок",
        badge: "-10% сегодня",
        desc: "Ягодный микс с мягкой прохладой. Сбалансировано — не “компот” и не “леденец”.",
      },
      uk: {
        name: "Одноразовий вейп Berry Rush",
        flavor: "Ягоди • Легкий холодок",
        badge: "-10% сьогодні",
        desc: "Ягідний мікс із м'якою прохолодою. Збалансовано — не “компот” і не “льодяник”.",
      },
      en: {
        name: "Disposable Vape Berry Rush",
        flavor: "Berries • Light chill",
        badge: "-10% today",
        desc: "Berry mix with a soft chill. Balanced — not a candy bomb, not a watered drink.",
      },
    },
  },
  {
    id: "np-cola-4000",
    category: "vapes",
    accent: "cola",
    emoji: "🥤",
    price_uah: 1590,
    puffs: 4000,
    nicotine: "2% (20mg/ml)",
    i18n: {
      ru: {
        name: "Одноразовый вейп Cola",
        flavor: "Кола • Лёд",
        badge: "Классика",
        desc: "Кола с холодком. Вкус знакомый, тяга стабильная — отличный “ежедневный” вариант.",
      },
      uk: {
        name: "Одноразовий вейп Cola",
        flavor: "Кола • Лід",
        badge: "Класика",
        desc: "Кола з холодком. Знайомий смак і стабільна тяга — хороший “на щодень” варіант.",
      },
      en: {
        name: "Disposable Vape Cola",
        flavor: "Cola • Ice",
        badge: "Classic",
        desc: "Cola with ice. Familiar taste, stable hit — an easy daily option.",
      },
    },
  },
  {
    id: "np-charger-usb",
    category: "accessories",
    accent: "mono",
    emoji: "🔌",
    price_uah: 290,
    puffs: null,
    nicotine: null,
    i18n: {
      ru: {
        name: "Кабель USB‑C",
        flavor: "Аксессуар",
        badge: "Нужно всем",
        desc: "Короткий USB‑C кабель для зарядки совместимых устройств.",
      },
      uk: {
        name: "Кабель USB‑C",
        flavor: "Аксесуар",
        badge: "Потрібно всім",
        desc: "Короткий кабель USB‑C для заряджання сумісних пристроїв.",
      },
      en: {
        name: "USB‑C Cable",
        flavor: "Accessory",
        badge: "Must‑have",
        desc: "Short USB‑C cable for charging compatible devices.",
      },
    },
  },
  {
    id: "np-case",
    category: "accessories",
    accent: "mono",
    emoji: "🧷",
    price_uah: 390,
    puffs: null,
    nicotine: null,
    i18n: {
      ru: {
        name: "Чехол‑капсула",
        flavor: "Аксессуар",
        badge: "Защита",
        desc: "Компактный чехол для переноски. Меньше царапин — больше спокойствия.",
      },
      uk: {
        name: "Чохол‑капсула",
        flavor: "Аксесуар",
        badge: "Захист",
        desc: "Компактний чохол для перенесення. Менше подряпин — більше спокою.",
      },
      en: {
        name: "Capsule Case",
        flavor: "Accessory",
        badge: "Protection",
        desc: "Compact carry case. Fewer scratches, more peace of mind.",
      },
    },
  },
];

